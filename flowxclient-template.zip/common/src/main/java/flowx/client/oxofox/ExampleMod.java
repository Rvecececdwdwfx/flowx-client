package flowx.client.oxofox;

public class ExampleMod {
    public static final String MOD_ID = "flowxclient";

    public static void init() {
        System.out.println("Hello World!");
    }
}
