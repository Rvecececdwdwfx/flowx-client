package flowx.client.oxofox.hud;

final class HudEditorState {
    String draggingModuleId;
    float dragOffsetX;
    float dragOffsetY;
    boolean wasMouseDown;
}
