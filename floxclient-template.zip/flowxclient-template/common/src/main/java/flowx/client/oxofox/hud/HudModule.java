package flowx.client.oxofox.hud;

import net.minecraft.client.gui.ScaledResolution;

public interface HudModule {
    String getId();

    default HudModulePos getDefaultPos() {
        return HudModulePos.of(4, 4, HudAnchor.TOP_LEFT);
    }

    /**
     * Called every frame during HUD rendering.
     *
     * Note: Modules should do all OpenGL state setup locally, or reset it before returning.
     */
    void render(float mouseX, float mouseY, float partialTicks, ScaledResolution resolution, HudModulePos pos);

    /**
     * Editor support: bounding box used for hit-testing + dragging.
     * Coordinates are in the same space as HudModulePos.x/y (screen pixels).
     */
    HudRect getBounds(float partialTicks, ScaledResolution resolution, HudModulePos pos);

    default void setChromaEnabled(boolean enabled) {}

    default void onEditorToggled(boolean enabled) {}
}
