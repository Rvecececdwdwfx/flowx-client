package flowx.client.oxofox.mixins;

import flowx.client.oxofox.hud.HudConfig;
import flowx.client.oxofox.hud.HudManager;
import flowx.client.oxofox.hud.client.FlowxHudClient;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.ScaledResolution;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(Minecraft.class)
public class HudOverlayMixin {
    @Inject(method = "renderGameOverlay", at = @At("TAIL"))
    private void flowxclient$renderHud(float partialTicks, CallbackInfo ci) {
        Minecraft mc = Minecraft.getMinecraft();
        if (mc == null) return;

        FlowxHudClient.initIfNeeded();
        HudConfig config = FlowxHudClient.getConfig();
        if (config == null) return;

        HudManager hud = FlowxHudClient.HUD;

        // Initialize scaled resolution like vanilla uses for GUI rendering.
        ScaledResolution resolution = new ScaledResolution(mc);

        float mouseX = mc.mouseHelper != null ? mc.mouseHelper.getMouseX() : 0.0f;
        float mouseY = mc.mouseHelper != null ? mc.mouseHelper.getMouseY() : 0.0f;

        hud.renderAll(mouseX, mouseY, partialTicks, resolution, config);
    }
}
