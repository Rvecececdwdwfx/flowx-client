package flowx.client.oxofox.hud.client;

import flowx.client.oxofox.hud.HudManager;
import net.minecraft.client.Minecraft;
import net.minecraft.client.settings.KeyBinding;
import net.minecraftforge.client.settings.ClientRegistry;

import org.lwjgl.input.Keyboard;

public final class FlowxHudKeybinds {
    public static final String CATEGORY = "flowxclient.hud";

    // TODO: later make this configurable in GUI
    private static KeyBinding toggleEditor;

    public static void init(HudManager hud) {
        if (toggleEditor != null) return;

        // Default to "G" (keyboard key code 34)
        toggleEditor = new KeyBinding("Toggle HUD Editor", Keyboard.KEY_G, CATEGORY);

        ClientRegistry.registerKeyBinding(toggleEditor);

        // Editor mode itself is toggled on each client tick (see HudKeybindTickMixin).
    }

    public static void onClientTick(HudManager hud) {
        if (toggleEditor == null) return;

        Minecraft mc = Minecraft.getMinecraft();
        if (mc == null || mc.player == null) return;

        if (toggleEditor.isPressed()) {
            hud.setEditorMode(!hud.isEditorMode());
            if (FlowxHudClient.getConfig() != null) {
                FlowxHudClient.getConfig().getSnapGrid(); // touch config for safety
            }
        }
    }
}
