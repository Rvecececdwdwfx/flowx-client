package flowx.client.oxofox.hud;

public final class HudModulePos {
    public final float x;
    public final float y;
    public final HudAnchor anchor;

    public HudModulePos(float x, float y, HudAnchor anchor) {
        this.x = x;
        this.y = y;
        this.anchor = anchor;
    }

    public static HudModulePos of(float x, float y, HudAnchor anchor) {
        return new HudModulePos(x, y, anchor);
    }
}
