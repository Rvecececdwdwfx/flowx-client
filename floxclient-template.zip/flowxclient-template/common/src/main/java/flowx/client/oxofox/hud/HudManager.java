package flowx.client.oxofox.hud;

import net.minecraft.client.gui.ScaledResolution;
import org.lwjgl.input.Mouse;

import java.util.Collections;
import java.util.HashMap;
import java.util.Map;

public final class HudManager {
    private final Map<String, HudModule> modules = new HashMap<>();
    private final HudEditorState editorState = new HudEditorState();

    private boolean editorMode;
    private int snapGrid;

    private boolean chromaEnabled;

    public void register(HudModule module) {
        modules.put(module.getId(), module);
    }

    public HudModule get(String moduleId) {
        return modules.get(moduleId);
    }

    public Map<String, HudModule> getModules() {
        return Collections.unmodifiableMap(modules);
    }

    public boolean isEditorMode() {
        return editorMode;
    }

    public void setEditorMode(boolean editorMode) {
        this.editorMode = editorMode;

        // Reset drag state when turning editor off to avoid "stuck" drags.
        if (!editorMode) {
            editorState.draggingModuleId = null;
        }

        for (HudModule module : modules.values()) {
            module.onEditorToggled(editorMode);
        }
    }

    public void setSnapGrid(int snapGrid) {
        this.snapGrid = Math.max(1, snapGrid);
    }

    public int getSnapGrid() {
        return snapGrid;
    }

    public boolean isChromaEnabled() {
        return chromaEnabled;
    }

    public void setChromaEnabled(boolean chromaEnabled) {
        this.chromaEnabled = chromaEnabled;
        for (HudModule module : modules.values()) {
            module.setChromaEnabled(chromaEnabled);
        }
    }

    private float snap(float value) {
        if (snapGrid <= 1) return value;
        return Math.round(value / snapGrid) * snapGrid;
    }

    public void renderAll(
            float mouseX,
            float mouseY,
            float partialTicks,
            ScaledResolution resolution,
            HudConfig config
    ) {
        if (editorMode) {
            boolean mouseDown = Mouse.isButtonDown(0);

            // Grab on mouse-down edge (prevents snapping weirdly every tick)
            if (mouseDown && !editorState.wasMouseDown) {
                for (HudModule module : modules.values()) {
                    HudModulePos defaults = module.getDefaultPos();
                    HudModulePos pos = config.getModulePos(module.getId(), defaults);

                    HudRect bounds = module.getBounds(partialTicks, resolution, pos);

                    if (bounds != null && bounds.contains(mouseX, mouseY)) {
                        editorState.draggingModuleId = module.getId();
                        editorState.dragOffsetX = mouseX - pos.x;
                        editorState.dragOffsetY = mouseY - pos.y;
                        break;
                    }
                }
            }

            // Update position while dragging
            if (editorState.draggingModuleId != null) {
                if (mouseDown) {
                    HudModule module = modules.get(editorState.draggingModuleId);
                    if (module != null) {
                        HudModulePos defaults = module.getDefaultPos();
                        HudModulePos pos = config.getModulePos(module.getId(), defaults);

                        float newX = snap(mouseX - editorState.dragOffsetX);
                        float newY = snap(mouseY - editorState.dragOffsetY);

                        config.setModulePos(module.getId(),
                                new HudModulePos(newX, newY, pos.anchor));

                        // Persist so the editor survives reloads even if the game crashes.
                        config.save();
                    }
                } else {
                    // mouse released
                    editorState.draggingModuleId = null;
                }
            }

            editorState.wasMouseDown = mouseDown;
        }

        for (HudModule module : modules.values()) {
            HudModulePos defaults = module.getDefaultPos();
            HudModulePos pos = config.getModulePos(module.getId(), defaults);
            module.render(mouseX, mouseY, partialTicks, resolution, pos);
        }
    }
}
