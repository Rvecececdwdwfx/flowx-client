package flowx.client.oxofox.hud;

import net.minecraftforge.common.config.Configuration;

import java.io.File;

public final class HudConfig {
    public static final String MODID = "flowxclient";
    public static final String CATEGORY_HUD = "hud";
    public static final String CATEGORY_GENERAL = "general";

    private final Configuration configuration;

    public HudConfig(File configDir) {
        this.configuration = new Configuration(new File(configDir, MODID + ".cfg"));
        this.configuration.load();
    }

    public boolean isEditorEnabledByDefault() {
        return configuration.getBoolean("editorEnabledByDefault", CATEGORY_GENERAL, false, "Enable HUD editor by default");
    }

    public int getSnapGrid() {
        return configuration.getInt("snapGrid", CATEGORY_GENERAL, 8, 1, 64, "HUD drag snap grid (pixels)");
    }

    public boolean isChromaEnabled() {
        return configuration.getBoolean("chromaEnabled", CATEGORY_GENERAL, false, "Enable RGB/chroma accent colors");
    }

    public void setChromaEnabled(boolean value) {
        configuration.getBoolean("chromaEnabled", CATEGORY_GENERAL, value, "Enable RGB/chroma accent colors");
        // configuration auto-saves on save(), but Forge config requires updating via getBoolean again above.
    }

    public HudModulePos getModulePos(String moduleId, HudModulePos defaults) {
        final String keyX = moduleId + ".x";
        final String keyY = moduleId + ".y";

        int x = configuration.getInt(keyX, CATEGORY_HUD, (int) defaults.x, -50000, 50000, "HUD module X");
        int y = configuration.getInt(keyY, CATEGORY_HUD, (int) defaults.y, -50000, 50000, "HUD module Y");

        // Anchor kept as a string so we can extend later without breaking config.
        String anchorStr = configuration.getString(moduleId + ".anchor", CATEGORY_HUD, defaults.anchor.name(), "HUD module anchor");
        HudAnchor anchor = HudAnchor.fromName(anchorStr);

        return new HudModulePos(x, y, anchor);
    }

    public void setModulePos(String moduleId, HudModulePos pos) {
        configuration.getInt(moduleId + ".x", CATEGORY_HUD, (int) pos.x, -50000, 50000, "HUD module X").set(pos.x);
        configuration.getInt(moduleId + ".y", CATEGORY_HUD, (int) pos.y, -50000, 50000, "HUD module Y").set(pos.y);
        configuration.getString(moduleId + ".anchor", CATEGORY_HUD, pos.anchor.name(), "HUD module anchor");
    }

    public void save() {
        if (configuration.hasChanged()) configuration.save();
    }

    public void close() {
        configuration.save();
    }
}
