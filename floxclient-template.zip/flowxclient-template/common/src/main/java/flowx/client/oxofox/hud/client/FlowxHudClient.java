package flowx.client.oxofox.hud.client;

import flowx.client.oxofox.hud.HudConfig;
import flowx.client.oxofox.hud.HudManager;
import flowx.client.oxofox.hud.client.FlowxHudKeybinds;
import flowx.client.oxofox.hud.modules.FpsModule;
import net.minecraft.client.Minecraft;

import java.io.File;

public final class FlowxHudClient {
    public static final HudManager HUD = new HudManager();

    private static HudConfig config;

    public static void initIfNeeded() {
        if (config != null) return;

        Minecraft mc = Minecraft.getMinecraft();
        if (mc == null) return;

        File configDir = new File(mc.mcDataDir, "config");
        // We'll use HudConfig's own file naming (flowxclient.cfg) under that directory.
        config = new HudConfig(configDir);

        HUD.setSnapGrid(config.getSnapGrid());
        HUD.setChromaEnabled(config.isChromaEnabled());

        HUD.register(new FpsModule());

        // Ensure keybinds are registered once (toggle editor with key G).
        FlowxHudKeybinds.init(HUD);

        HUD.setEditorMode(config.isEditorEnabledByDefault());
    }

    public static HudConfig getConfig() {
        return config;
    }

    public static void save() {
        if (config != null) config.save();
    }

    public static void setChromaEnabled(boolean enabled) {
        HUD.setChromaEnabled(enabled);
        if (config != null) config.setChromaEnabled(enabled);
    }
}
