package flowx.client.oxofox.hud;

public enum HudAnchor {
    TOP_LEFT("top_left"),
    TOP_RIGHT("top_right"),
    BOTTOM_LEFT("bottom_left"),
    BOTTOM_RIGHT("bottom_right"),
    CENTER("center");

    public final String name;

    HudAnchor(String name) {
        this.name = name;
    }

    public static HudAnchor fromName(String name) {
        for (HudAnchor anchor : values()) {
            if (anchor.name.equalsIgnoreCase(name)) return anchor;
        }
        return TOP_LEFT;
    }
}
