package flowx.client.oxofox.mixins;

import flowx.client.oxofox.hud.client.FlowxHudClient;
import flowx.client.oxofox.hud.client.FlowxHudKeybinds;
import flowx.client.oxofox.hud.HudManager;
import net.minecraft.client.Minecraft;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(Minecraft.class)
public class HudKeybindTickMixin {
    @Inject(method = "runTick", at = @At("HEAD"))
    private void flowxclient$onRunTick(boolean renderWorld, CallbackInfo ci) {
        HudManager hud = FlowxHudClient.HUD;
        FlowxHudKeybinds.onClientTick(hud);
    }
}
