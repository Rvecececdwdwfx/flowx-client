package flowx.client.oxofox.hud.modules;

import flowx.client.oxofox.hud.HudModule;
import flowx.client.oxofox.hud.HudModulePos;
import flowx.client.oxofox.hud.HudRect;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.ScaledResolution;

public final class FpsModule implements HudModule {
    @Override
    public String getId() {
        return "fps";
    }

    @Override
    public HudRect getBounds(float partialTicks, ScaledResolution resolution, HudModulePos pos) {
        Minecraft mc = Minecraft.getMinecraft();
        if (mc == null || mc.gameSettings.hideGUI) return new HudRect(pos.x, pos.y, 1, 1);

        int fps = mc.getDebugFPS();
        if (fps <= 0) return new HudRect(pos.x, pos.y, 1, 1);

        String text = "FPS: " + fps;
        int width = mc.fontRendererObj.getStringWidth(text);
        int height = mc.fontRendererObj.FONT_HEIGHT;

        return new HudRect(pos.x, pos.y, width, height);
    }

    @Override
    public void render(
            float mouseX,
            float mouseY,
            float partialTicks,
            ScaledResolution resolution,
            HudModulePos pos
    ) {
        Minecraft mc = Minecraft.getMinecraft();
        if (mc.gameSettings.hideGUI) return;

        int fps = mc.getDebugFPS();
        if (fps <= 0) return;

        // For now treat pos.x/pos.y as top-left offsets.
        int x = (int) pos.x;
        int y = (int) pos.y;

        mc.fontRendererObj.drawStringWithShadow("FPS: " + fps, x, y, 0xFFFFFF);
    }
}
